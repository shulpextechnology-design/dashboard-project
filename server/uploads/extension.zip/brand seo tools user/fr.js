$(".medium").remove();
$(".icon--credit-card").remove();
$(".gr-auth__logout-button").remove();
$(".col--center").remove();
$(".icon--support").remove();
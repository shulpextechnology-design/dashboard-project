$("#user-logout").remove();
$(".welcomeuser").remove();
$("#ui-id-5").remove();
$("#ui-id-6").remove();
$("#ui-id-7").remove();
$("#ui-id-8").remove();
$("#topmenu").remove();
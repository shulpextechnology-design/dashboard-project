$('body').mouseover(function() {
$(".src-apps-picmonkey-components-top_bar--styles-account-2jBic").remove();
$(".src-core-components-top_bar--styles-account-lgjr6").remove();
$(".src-core-components--footer-footer-3GU5J").remove();
$(".src-home-components--signed_in_home-sidebar-3yOaT").remove();
$('a[href="/blog/new-picmonkey"]').remove();
$('[data-name="more"]').remove();
$("#ctrl-bar-share").remove();
$('.src-home-components--gdpr_banner-gdpr_banner-3PB5v').remove();
$("footer").remove();
});

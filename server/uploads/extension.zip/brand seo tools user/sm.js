$(".tn-upgrade").remove();
$("[data-test='header-menu__user']").html("");


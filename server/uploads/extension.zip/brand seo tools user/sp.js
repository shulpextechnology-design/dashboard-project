$(".dropdown-toggle").remove();
